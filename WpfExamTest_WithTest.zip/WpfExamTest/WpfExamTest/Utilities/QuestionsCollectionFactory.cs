﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Interfaces;
using WpfExamTest.Models;

namespace WpfExamTest.Utilities
{
    public class QuestionsCollectionFactory : IQuestionsCollectionFactory
    {
        public QuestionsCollectionBase GetQuestionsCollection(string CollectionType)
        {
           
            switch (CollectionType)
            {
                case "General Knowledge":
                    return new GKQuestionsCollection();
                case "Maths":
                    return new MathsQuestionsCollection();
                default:
                    return null;
                    break;
            }
        }
    }
}
