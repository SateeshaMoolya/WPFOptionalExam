﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Commands;
using WpfExamTest.Models;
using WpfExamTest.Utilities;

namespace WpfExamTest.ViewModel
{
    public abstract class NotifyBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void RaisePropetyChanged(string propertyName)
        {
            if (null != PropertyChanged)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
    internal class TestViewModel : NotifyBase
    {
        private readonly string[] myTopics = new string[] {"General Knowledge", "Maths"};
        private readonly QuestionsCollectionFactory myQuestionsCollectionFactory = new QuestionsCollectionFactory();
        public TestViewModel()
        {
            TimerModel = new TimerModel();
            
            this.NextCommand = new NextCommand();
            this.PreviousCommand = new PreviousCommand();
            UserInformation = new UserInformation();
            Topics = myTopics;
        }
        public TimerModel TimerModel { get; set; }
        public QuestionsCollectionBase QuestionsCollection { get; set; }
        public NextCommand NextCommand { get; set; }
        public PreviousCommand PreviousCommand { get; set; }
        public UserInformation UserInformation { get; set; }

        public ResultModel ResultModel { get; set; }
        public string[] Topics { get; set; }

        private string mySelectedTopic;
        public string SelectedTopic {
            get { return mySelectedTopic; }
            set
            {
                mySelectedTopic = value;
                RaisePropetyChanged("SelectedTopic");
                QuestionsCollection = myQuestionsCollectionFactory.GetQuestionsCollection(mySelectedTopic);
                ResultModel = new ResultModel(QuestionsCollection);
            }
        }
    }
}
