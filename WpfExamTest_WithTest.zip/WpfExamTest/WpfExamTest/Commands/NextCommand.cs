﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfExamTest.Interfaces;

namespace WpfExamTest.Commands
{
    public class NextCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            if (null == parameter)
            {
                return true;
            }
            IQuestionNavigator navigator = (IQuestionNavigator)parameter;
            return navigator.CanNavigate(false);
        }

        public void Execute(object parameter)
        {
            IQuestionNavigator navigator = (IQuestionNavigator)parameter;
            navigator.Next();
        }
    }

    public class PreviousCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            if (null== parameter)
            {
                return true;
            }
            IQuestionNavigator navigator = (IQuestionNavigator)parameter;
            return navigator.CanNavigate(true);
        }

        public void Execute(object parameter)
        {
            IQuestionNavigator navigator = (IQuestionNavigator)parameter;
            navigator.Previous();
        }
    }
}
