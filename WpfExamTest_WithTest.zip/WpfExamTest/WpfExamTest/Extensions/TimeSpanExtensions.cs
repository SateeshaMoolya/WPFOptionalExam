﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExamTest.Extensions
{
    public static class TimeSpanExtensions
    {
        public static string ToStringNoDays(this TimeSpan source)
                  => $"{(int)source.TotalHours}:{source.ToString(@"mm\:ss")}";
    }
}
