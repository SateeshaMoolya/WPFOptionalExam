﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfExamTest.UserControls;
using WpfExamTest.ViewModel;

namespace WpfExamTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            myLoginControl.StartClicked += MyLoginControl_StartClicked;
        }

        private void MyLoginControl_StartClicked(object sender, EventArgs e)
        {
            myPanel.Children.RemoveAt(myPanel.Children.Count - 1);
            MainUserControl mainUserControl = new MainUserControl();
            TestViewModel viewModel = DataContext as TestViewModel;
            mainUserControl.SubmitClicked += MainUserControl_SubmitClicked;
            myPanel.Children.Add(mainUserControl);
            viewModel.TimerModel.StartTimer();
        }

        private void MainUserControl_SubmitClicked(object sender, EventArgs e)
        {
            myPanel.Children.RemoveAt(myPanel.Children.Count - 1);
            myPanel.Children.Add(new ResultControl());
        }
    }
}
