﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Models;

namespace WpfExamTest.Interfaces
{
    public interface IQuestionsCollectionFactory
    {
        QuestionsCollectionBase GetQuestionsCollection(string CollectionType);
    }
}
