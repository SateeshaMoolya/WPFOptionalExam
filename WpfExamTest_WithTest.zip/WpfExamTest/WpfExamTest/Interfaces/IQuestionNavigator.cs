﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Models;

namespace WpfExamTest.Interfaces
{
    public interface IQuestionNavigator
    {
        Question Previous();

        Question Next();

        bool CanNavigate(bool previous);
    }
}
