﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfExamTest.Interfaces
{
    public interface IResultCalculator
    {
        int GetTotalMarks();
        int GetResultedMarks();        
    }
}
