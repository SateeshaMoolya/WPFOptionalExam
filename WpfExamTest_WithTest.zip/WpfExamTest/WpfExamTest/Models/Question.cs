﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.ViewModel;

namespace WpfExamTest.Models
{
    public class Question: NotifyBase
    {
        public int QuestionNo { get; set; }
        public string QuestionString { get; set; }

        public string Option1 { get; set; }

        public string Option2 { get; set; }

        public string Option3 { get; set; }

        public string Option4 { get; set; }

        public TestOptions Answer { get; set; }

        private TestOptions myUserSelectedAns;
        public TestOptions UserSelectedAns {
            get { return myUserSelectedAns; }
            set
            {
                myUserSelectedAns = value;
                RaisePropetyChanged("UserSelectedAns");
            }
        }

        public int Marks { get; set; }
    }

    public enum TestOptions
    {
        opt1,
        opt2,
        opt3,
        opt4,
        none
    }
}
