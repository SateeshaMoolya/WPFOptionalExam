﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Interfaces;
using WpfExamTest.ViewModel;

namespace WpfExamTest.Models
{
    public class ResultModel: NotifyBase
    {
        readonly IResultCalculator myResultCalculator;
        public ResultModel(IResultCalculator resultCalculator)
        {
            myResultCalculator = resultCalculator;
        }

        public int TotalMarks { get { return myResultCalculator.GetTotalMarks(); } }

        public int ResultedMarks { get { return myResultCalculator.GetResultedMarks(); } }

        public bool IsPassed { get { return HasPassed(); } }

        private bool HasPassed()
        {
            if (TotalMarks==0)
            {
                return false;
            }
            else if(ResultedMarks/TotalMarks>=60)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
