﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using WpfExamTest.Extensions;
using WpfExamTest.ViewModel;
using System.Configuration;

namespace WpfExamTest.Models
{
    public class TimerModel: NotifyBase
    {
        private DateTime myStartTime;
        TimeSpan myTimeSpent;
        DispatcherTimer myDispatcherTimer = new DispatcherTimer();
        public TimerModel()
        {
            myDispatcherTimer.Tick += MyDispatcherTimer_Tick;
            myDispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            IsTimeAvailable = true;            
        }

        public void StartTimer()
        {
            myStartTime = DateTime.Now;
            myDispatcherTimer.Start();
        }

        private string mySpentTime;
        public string SpentTime
        {
            get { return mySpentTime; }
            set
            {
                mySpentTime = value;
                RaisePropetyChanged("SpentTime");
            }
        }
        private void MyDispatcherTimer_Tick(object sender, EventArgs e)
        {
            myTimeSpent = DateTime.Now - myStartTime;
            string data =ConfigurationSettings.AppSettings["ExamTimeSpanMinutes"];
            int timeInMins = Convert.ToInt32(data);

            SpentTime = myTimeSpent.ToStringNoDays();
            if (myTimeSpent.Minutes== timeInMins)
            {
                myDispatcherTimer.Stop();
                IsTimeAvailable = false;
            }
        }

        private bool myIsTimeReached;

        public bool IsTimeAvailable
        {
            get { return myIsTimeReached; }
            set { myIsTimeReached = value; RaisePropetyChanged("IsTimeAvailable"); }
        }


        ~TimerModel()
        {
            if (myDispatcherTimer.IsEnabled)
            {
                myDispatcherTimer.Stop();
            }
        }
    }
}
