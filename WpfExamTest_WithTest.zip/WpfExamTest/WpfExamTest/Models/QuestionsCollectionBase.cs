﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Interfaces;
using WpfExamTest.ViewModel;

namespace WpfExamTest.Models
{
    public class QuestionsCollectionBase: NotifyBase, IQuestionNavigator, IResultCalculator
    {
        protected LinkedList<Question> myQuestions;
        protected LinkedListNode<Question> myCurrentNode;
        public QuestionsCollectionBase()
        {
            myQuestions = new LinkedList<Question>();
           
        }
        private Question myCurrentQuestion;
        public Question CurrentQuestion
        {
            get { return myCurrentQuestion; }
            set
            {
                myCurrentQuestion = value;
                RaisePropetyChanged("CurrentQuestion");
            }
        }

        public Question Next()
        {
            if (myCurrentNode == null)
            {
                myCurrentNode = myQuestions.First;
            }
            else
            {
                myCurrentNode = myCurrentNode.Next;
            }
            CurrentQuestion = myCurrentNode.Value;
            return myCurrentNode.Value;
        }

        public Question Previous()
        {
            myCurrentNode = myCurrentNode.Previous;
            CurrentQuestion = myCurrentNode.Value;
            return myCurrentNode.Value;
        }

        public bool CanNavigate(bool previous)
        {
            if (previous)
            {
                return (myCurrentNode.Previous != null);
            }
            return (myCurrentNode.Next != null);
        }

        public int GetTotalMarks()
        {
            int result = 0;
            var node = myQuestions.First;
            while (node != null)
            {
                result += node.Value.Marks;
                node = node.Next;
            }
            return result;
        }

        public int GetResultedMarks()
        {
            int result = 0;
            var node = myQuestions.First;
            while (node != null)
            {
                if (node.Value.Answer==node.Value.UserSelectedAns)
                {
                    result += node.Value.Marks;
                }
                node = node.Next;
            }
            return result;
        }
    }
}
