﻿using System.Collections.Generic;
using WpfExamTest.Data;
using WpfExamTest.Interfaces;
using WpfExamTest.ViewModel;

namespace WpfExamTest.Models
{
    public sealed class MathsQuestionsCollection: QuestionsCollectionBase
    {
        public MathsQuestionsCollection() : base()
        {
            int i = 0;
            LinkedListNode<Question> node=null;
            MathsData mathsData = new MathsData();
            foreach (var item in mathsData.Data)
            {
                i++;
                item.QuestionNo = i;
                item.UserSelectedAns = TestOptions.none;
                if (i==1)
                {
                    node = myQuestions.AddFirst(item);
                    continue;
                }
                node = myQuestions.AddAfter(node,item);
            }
            Next();
        }
    }
}
