﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Data;

namespace WpfExamTest.Models
{
    public class GKQuestionsCollection: QuestionsCollectionBase
    {
        public GKQuestionsCollection()
        {
            int i = 0;
            LinkedListNode<Question> node = null;
            GKData mathsData = new GKData();
            foreach (var item in mathsData.Data)
            {
                i++;
                item.QuestionNo = i;
                item.UserSelectedAns = TestOptions.none;
                if (i == 1)
                {
                    node = myQuestions.AddFirst(item);
                    continue;
                }
                node = myQuestions.AddAfter(node, item);
            }
            Next();
        }
    }
}
