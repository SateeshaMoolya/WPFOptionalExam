﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace WpfExamTest.Converters
{
    public class StartEnabledConverter : IMultiValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string user = string.Empty;
            string topic = string.Empty;
            if (null!=value)
            {
                user = (string)value;
            }
            if (parameter!=null)
            {
                topic = (string)parameter;
            }
            if (!string.IsNullOrEmpty(user)&& !string.IsNullOrEmpty(topic))
            {
                return true;
            }
            return false;
        }

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            string user = string.Empty;
            string topic = string.Empty;
            if (null != values[0])
            {
                user = (string)values[0];
            }
            if (values[1] != null)
            {
                topic = (string)values[1];
            }
            if (!string.IsNullOrEmpty(user) && !string.IsNullOrEmpty(topic))
            {
                return true;
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
