﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Models;

namespace WpfExamTest.Data
{
    internal class MathsData
    {
        public MathsData()
        {
            Data = new List<Question>();
            AddData();
        }

        public List<Question> Data { get; }
        public void AddData()
        {
            Data.Add(new Question
            {
                QuestionString = "What is the result of 1+2=?",
                Option1 = "3",
                Option2 = "2",
                Option3 = "4",
                Option4 = "0",
                Answer = TestOptions.opt1,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is the result of 5-1=?",
                Option1 = "8",
                Option2 = "4",
                Option3 = "9",
                Option4 = "1",
                Answer = TestOptions.opt2,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is the result of Cos(90)=?",
                Option1 = "1",
                Option2 = "Infinity",
                Option3 = "90",
                Option4 = "0",
                Answer = TestOptions.opt4,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is the result of 90*0=?",
                Option1 = "0",
                Option2 = "1",
                Option3 = "180",
                Option4 = "5",
                Answer = TestOptions.opt1,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is the result of 0/20=?",
                Option1 = "3",
                Option2 = "2",
                Option3 = "4",
                Option4 = "0",
                Answer = TestOptions.opt4,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What binary value of 2?",
                Option1 = "10",
                Option2 = "2",
                Option3 = "12",
                Option4 = "01",
                Answer = TestOptions.opt1,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is square value of 5?",
                Option1 = "5",
                Option2 = "25",
                Option3 = "10",
                Option4 = "15",
                Answer = TestOptions.opt2,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is square root of 100?",
                Option1 = "5",
                Option2 = "2",
                Option3 = "10",
                Option4 = "infinity",
                Answer = TestOptions.opt3,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "What is 5% 100?",
                Option1 = "0",
                Option2 = "5",
                Option3 = "34",
                Option4 = "89",
                Answer = TestOptions.opt2,
                Marks = 1
            });
            Data.Add(new Question
            {
                QuestionString = "Triangle has _____ sides",
                Option1 = "3",
                Option2 = "2",
                Option3 = "4",
                Option4 = "0",
                Answer = TestOptions.opt1,
                Marks = 1
            });
        }
    }
}
