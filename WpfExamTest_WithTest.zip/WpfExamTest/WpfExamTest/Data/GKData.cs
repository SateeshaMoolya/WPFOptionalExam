﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Models;

namespace WpfExamTest.Data
{
    internal class GKData {
        public GKData()
        {
            Data = new List<Question>();
            AddData();
        }

        public List<Question> Data { get; }
        public void AddData()
    {
        Data.Add(new Question
        {
            QuestionString = "Who is our prime minister?",
            Option1 = "Narendara Modi",
            Option2 = "Manmohan Singh",
            Option3 = "Yediyurappa",
            Option4 = "Devegowda",
            Answer = TestOptions.opt1,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "The capital of Uttarakhand is____",
            Option1 = "Masoori",
            Option2 = "Dehra Dun",
            Option3 = "Nainital",
            Option4 = "None of these",
            Answer = TestOptions.opt2,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "Geet Govind is a famous creation of______",
            Option1 = "Bana Bhatt",
            Option2 = "Kalidas",
            Option3 = "JayaDev",
            Option4 = "Bharat Muni",
            Answer = TestOptions.opt3,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "World Trade Organization came into existance in______",
            Option1 = "1992",
            Option2 = "1993",
            Option3 = "1994",
            Option4 = "1995",
            Answer = TestOptions.opt4,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "Panchayathi Raj comes under______",
            Option1 = "Residual List",
            Option2 = "Concurrent List",
            Option3 = "State List",
            Option4 = "Union List",
            Answer = TestOptions.opt3,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "The literacy rate of India is___",
            Option1 = "57.86%",
            Option2 = "61.34%",
            Option3 = "63.98%",
            Option4 = "65.38%",
            Answer = TestOptions.opt4,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "SAARC was formed in____",
            Option1 = "1982",
            Option2 = "1984",
            Option3 = "1985",
            Option4 = "1986",
            Answer = TestOptions.opt3,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "What is the capital of Karnataka?",
            Option1 = "Mumbai",
            Option2 = "Bengaluru",
            Option3 = "Mysore",
            Option4 = "Mangalore",
            Answer = TestOptions.opt2,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "Human Body has ___ bones",
            Option1 = "34",
            Option2 = "206",
            Option3 = "100",
            Option4 = "1000",
            Answer = TestOptions.opt2,
            Marks = 1
        });
        Data.Add(new Question
        {
            QuestionString = "Electric Bulb was invented by _________",
            Option1 = "Archemidis",
            Option2 = "Thomas Alva Edison",
            Option3 = "Barbar",
            Option4 = "None of the Above",
            Answer = TestOptions.opt2,
            Marks = 1
        });
    }
}
}
