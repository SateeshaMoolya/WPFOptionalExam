﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WpfExamTest.Interfaces;

namespace Test
{
    [TestClass]
    public class IQuestionNavigatorTest
    {
        [TestMethod]
        public void TestCanNavigatePreviousWithoutFirstNodeShouldThrowException()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();            
            Exception expectedExcetpion = null;
            try
            {
                var result = navigator.CanNavigate(true);
            }
            catch (Exception ex)
            {
                expectedExcetpion = ex;
            }

            // Assert
            Assert.IsNotNull(expectedExcetpion);
        }
        [TestMethod]
        public void TestCanNavigatePreviousWithFirstNodeShouldReturnFalse()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            var result = navigator.CanNavigate(true);
            // Assert
            Assert.AreEqual(false,result);
        }
        [TestMethod]
        public void TestCanNavigateNextWithFirstNodeShouldReturnTrue()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            var result = navigator.CanNavigate(false);
            // Assert
            Assert.AreEqual(true, result);
        }

        [TestMethod]
        public void TestCanNavigatePreviousWithSecondNodeShouldReturnTrue()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            navigator.Next();
            var result = navigator.CanNavigate(true);
            // Assert
            Assert.AreEqual(true, result);
        }
        [TestMethod]
        public void TestCanNavigateNextWithSecondNodeShouldReturnTrue()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            navigator.Next();
            var result = navigator.CanNavigate(false);
            // Assert
            Assert.AreEqual(true, result);
        }
        [TestMethod]
        public void TestCanNavigatePreviousWithLastNodeShouldReturnTrue()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            navigator.Next();
            navigator.Next();
            var result = navigator.CanNavigate(true);
            // Assert
            Assert.AreEqual(true, result);
        }
        [TestMethod]
        public void TestCanNavigateNextWithLastNodeShouldReturnFalse()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            navigator.Next();
            navigator.Next();
            var result = navigator.CanNavigate(false);
            // Assert
            Assert.AreEqual(false, result);
        }

        [TestMethod]
        public void TestNavigateNextWithoutFistNodeShouldReturnFirstNode()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            var result=navigator.Next();
            
            // Assert
            Assert.AreEqual(1, result.QuestionNo);
        }

        [TestMethod]
        public void TestNavigateNextWithLastNodeShouldThrowException()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            //TODO:BelowMetodShould be stubbed/Faked
            navigator.Next();
            navigator.Next();
            navigator.Next();

            Exception expectedExcetpion = null;
            try
            {
                var result = navigator.Next();
            }
            catch (Exception ex)
            {
                expectedExcetpion = ex;
            }

            // Assert
            Assert.IsNotNull(expectedExcetpion);
        }
        [TestMethod]
        public void TestNavigatePreviousWithoutFirstNodeShouldThrowException()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            Exception expectedExcetpion = null;
            try
            {
                var result = navigator.Previous();
            }
            catch (Exception ex)
            {
                expectedExcetpion = ex;
            }

            // Assert
            Assert.IsNotNull(expectedExcetpion);
        }
        [TestMethod]
        public void TestNavigatePreviousWithFirstNodeShouldThrowException()
        {
            IQuestionNavigator navigator = new QuestionsCollectionFake();
            Exception expectedExcetpion = null;
            navigator.Next();
            try
            {
                var result = navigator.Previous();
            }
            catch (Exception ex)
            {
                expectedExcetpion = ex;
            }

            // Assert
            Assert.IsNotNull(expectedExcetpion);
        }
    }
}
