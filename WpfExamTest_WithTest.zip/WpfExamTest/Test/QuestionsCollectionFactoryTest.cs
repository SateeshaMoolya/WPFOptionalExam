﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WpfExamTest.Interfaces;
using WpfExamTest.Utilities;
using WpfExamTest.Models;

namespace Test
{
    [TestClass]
    public class QuestionsCollectionFactoryTest
    {
        [TestMethod]
        public void GetQuestionsCollectionWithGK()
        {
            QuestionsCollectionFactory factory = new QuestionsCollectionFactory();
            var result = factory.GetQuestionsCollection("General Knowledge");
            Assert.IsInstanceOfType(result ,typeof(GKQuestionsCollection));
        }

        [TestMethod]
        public void GetQuestionsCollectionWithMaths()
        {
            QuestionsCollectionFactory factory = new QuestionsCollectionFactory();
            var result = factory.GetQuestionsCollection("Maths");
            Assert.IsInstanceOfType(result, typeof(MathsQuestionsCollection));
        }

        [TestMethod]
        public void GetQuestionsCollectionWithInvalidValue()
        {
            QuestionsCollectionFactory factory = new QuestionsCollectionFactory();
            var result = factory.GetQuestionsCollection("invalid");
            Assert.AreEqual(null, result);
        }
    }
}
