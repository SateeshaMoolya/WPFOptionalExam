﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfExamTest.Models;

namespace Test
{
    class QuestionsCollectionFake: QuestionsCollectionBase
    {
        public QuestionsCollectionFake()
        {
            var node=myQuestions.AddFirst(new Question { QuestionString = "Q1", Answer = TestOptions.opt1, Marks = 1, Option1 = "1", Option2 = "2", Option3 = "3", Option4 = "1", QuestionNo = 1, UserSelectedAns = TestOptions.none });
            node = myQuestions.AddAfter(node,new Question { QuestionString = "Q2", Answer = TestOptions.opt2, Marks = 1, Option1 = "1", Option2 = "2", Option3 = "3", Option4 = "1", QuestionNo = 1, UserSelectedAns = TestOptions.none });
            node = myQuestions.AddAfter(node, new Question { QuestionString = "Q3", Answer = TestOptions.opt3, Marks = 1, Option1 = "1", Option2 = "2", Option3 = "3", Option4 = "1", QuestionNo = 1, UserSelectedAns = TestOptions.none });
            //Next();
        }
    }
}
